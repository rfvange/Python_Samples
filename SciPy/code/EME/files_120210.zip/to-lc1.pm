#!/home/cardinal/home10/rfv0515j/perl/perl
 
#$#ARGV >= 0 || die "No file specified\n";
foreach (`ls`) {
# next if /\.pm/;
  next if /[a-z]/;
  print;
  chop;
  ($file = $_) =~ y/A-Z/a-z/;
  print "$file\n";
# system("mv $_ $file");
}
