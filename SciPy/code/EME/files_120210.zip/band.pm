#!/home/cardinal/home10/rfv0515j/perl/perl
$#ARGV >= 1 || die "Usage: band.pm <fft_size> <num_ffts> - $!";
($fft_size, $num_ffts) = @ARGV;
#$fft_size = 512;
#$num_ffts = 200;
$band_low = int(0.006*$fft_size+0.5);
#$band_low = int(0.0586*$fft_size+0.5); # fract = bin/fft_size
$band_hi = int(0.0085*$fft_size+0.5);
#$band_hi = int(0.137*$fft_size+0.5);
$band_ulow = $fft_size - $band_low;
$band_uhi = $fft_size - $band_hi;
print "#band_low = $band_low,  band_hi = $band_hi\n";
print "#band_ulow = $band_ulow,  band_uhi = $band_uhi\n";
for($j=0;$j<$num_ffts;) {
  $_ = <STDIN>;
  next if /#/;
  print "#j = $j\n";
  print;
  $_ = <STDIN>;
  print;
  $j++;
  for($i=1;$i<$fft_size;) {
    $_ = <STDIN>;
    next if /#/;
    print "#i = $i\n";
    if(( $i >= $band_low && $i <= $band_hi ) ||
       ( $i >= $band_uhi && $i <= $band_ulow ) ) {
      print;
      $_ = <STDIN>;
      print;
    }
    else {
      print "0.0\n";
      $_ = <STDIN>;
      print "0.0\n";
    }
    $i++;
  }
}
