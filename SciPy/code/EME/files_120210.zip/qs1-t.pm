#!/home/cardinal/home10/rfv0515j/perl/perl
$count = 0;
$total = 0;
while(<>) {
  if($_ < 0 || $_ > 255) {
#    print;
    $count++;
  }
  $total++;
}
print "\nTotal = $count out of $total, or ",$count*100/$total," percent\n";
