#!/home/cardinal/home10/rfv0515j/perl/perl

while(<>) {
  next if /#/;
#  print;
  chomp;
  $val = hex($_);
#  print "$val\n";
  $val = pack("C",$val);
#  print "val = $val\n";
  syswrite(STDOUT,$val,1);
#  print "x";
}
