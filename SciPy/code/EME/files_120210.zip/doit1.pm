#!/home/cardinal/home10/rfv0515j/perl/perl
$p = 256;
$z = 256;
$cmd1 = qq/lam-flt out1-2a.out -z=$z -p=$p -l=.5 > out1-3a.out/;
$cmd2 = qq/fft2 out1-3a.out -z=$z -p=$p -i -v > out1-4a.out/;
$cmd3 = qq/to-wv.pm < out1-4a.out > out1-4a.wav/;
$cmd4 = qq/fft2 out1-1.out -z=$z -p=$p > out1-2a.out/;
system($cmd4);
system($cmd1);
system($cmd2);
system($cmd3);
