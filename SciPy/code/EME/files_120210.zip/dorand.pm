#!/home/cardinal/home10/rfv0515j/perl/perl
@ARGV >= 2 || die "Usage: dorand.pm <cycles> <points> <noise>\n";
($cy,$pt,$ns) = @ARGV;
$pi = 2.0*atan2(1.0,0.0);
#print "$pi\n";
$file = q/tsig.dat/;
$file1 = q/tsig1.dat/;
srand(time() ^ ($$ + ($$ << 3)));
system("rm $file") if -e $file;
open(FILE, ">$file");
for($i=0;$i<$pt;$i++) {
 $func = sin(2*$cy*$pi*$i/$pt);
 $a = rand(.9998) + .0001;
 $a = sqrt(-log($a));
 $a = rand()<0.5 ? -$a : $a;
#$a = $func;
 $a = $func + $ns * $a;
 print FILE "$a\n";
}
close FILE;
$res = `fft $file`;
@res = split(/\n/,$res);
print "The result is:\n";
#print $res;
#$i = 0;
$i = -1;
$~ = "ABC1";
system("rm $file1") if -e $file1;
open(FILE1, ">$file1");
foreach (@res) { if (/Mag = / || /fund/) {write; $i++;}}
$j = 0;
foreach (@res) { ($match) = /Mag = (\d+\.\d+)/;
  ($pmatch) = /Phase = (-?\d+\.\d+)/;
  $sort{$match} = $_ if $match;
  print "$match, $pmatch\n" if $match;
  if($match) {
    if($match > 0.5) { $res[$j] = $match*$pt; }
    else { $res[$j] = 0.0 }
  $j++;
  undef $match; }
}
for($i=0;$i<$pt/2;$i++) {print FILE1 "$res[$i]\n";}
print FILE1 "0.0\n";
for($i=0;$i<$pt/2-1;$i++) {print FILE1 "-$res[$pt/2-$i-1]\n";}
close FILE1;
#foreach (keys %sort) {print "key = $_, val = $sort{$_}\n";}
@xxx = reverse sort{ $a <=> $b } keys %sort;
foreach (@xxx) { print "$sort{$_}\n"; }
$res = `fft $file1`;
@res = split(/\n/,$res);
print "The result is:\n";
#print $res;
$~ = "ABC";
undef $i;
foreach (@res) { ($sign) = /Phase = (-?\d+\.\d+)/;
#  print "\$sign is $sign\n";
  s/Mag = (\d+\.\d+)/Mag = -$1/ if ($sign < 0);
  ($print) = /(Mag = -?\d+\.\d+)/;
#  print "$print\n";
  write if /Mag = /;}


format ABC=
@>>>> - @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$i,     $print
.

format ABC1=
@>>>> - @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$i,     $_
.
