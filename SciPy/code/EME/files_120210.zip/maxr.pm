#!/home/cardinal/home10/rfv0515j/perl/perl
while(1) {
  $_ = <STDIN>;
  last if eof();
  $pound = $_ if /#/;
  next unless /#/;
  $a = <STDIN>; $b = <STDIN>;
#  print "$a, $b, $pound\n";
  if($a < 0) { $a = -$a; }
  if($b < 0) { $b = -$b; }
  if($a >= $b) { $res = $a*(1+0.5*$b/$a); }
  else         { $res = $b*(1+0.5*$a/$b); }
  $intres = int($res*100);
#  $intres = int($res/50);
  if(defined $resarr{$intres}) {
    chop $resarr{$intres}; $resarr{$intres}.=", ".$pound; }
  else {
    $resarr{$intres}=$pound; }
  @test = keys %resarr;
#  print "dim of test is $#test\n";
#  print "int intres = $intres, pound = $resarr{$intres}\n";
  last if eof();
}
print "Now sort\n";
@test = keys %resarr;
print "dim of test is $#test\n";
#foreach(keys %resarr) { print "testing: $_\n"; }
@sres = reverse sort { $a <=> $b } keys %resarr;
foreach(@sres) {
  print "$_,  ", $resarr{$_};
}
