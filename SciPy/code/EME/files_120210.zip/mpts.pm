#!/home/cardinal/home10/rfv0515j/perl/perl
 
$#ARGV >= 0 || die "No files specified\n";

($infile,$pts) = @ARGV;
$pts = 4 unless $pts;
open(IN, "<$infile") || die "Error opening $infile\n";
@file = <IN>;
for($i=0;$i<$pts;$i++) {
  print "@file";
}
