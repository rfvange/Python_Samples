#!/home/cardinal/home10/rfv0515j/perl/perl
$bin = 0;
while(1) {
  $a = <STDIN>; $b = <STDIN>;
  chomp $a; chomp $b;
  if($a < 0) { $a = -$a; }
  if($b < 0) { $b = -$b; }
  if($a >= $b) { $res = $a*(1+0.5*$b/$a); }
  else         { $res = $b*(1+0.5*$a/$b); }
  if($res > $max) {
    $next2 = $next1; $maxa2 = $maxa1; $bin2 = $bin1;
    $next1 = $next0; $maxa1 = $maxa0; $bin1 = $bin0;
    $next0 = $max; $maxa0 = $maxa; $bin0 = $bina;
    $max = $res; $bina = $bin; $maxa = $a }
#  print "max = $max, bin = $bin\n";
  $bin++;
  last if eof(STDIN);
}
print "max is $max; maxa is $maxa; bin is $bina\n";
print "next0 is $next0; maxa0 = $maxa0; bin0 is $bin0\n";
print "next1 is $next1; maxa1 = $maxa1; bin1 is $bin1\n";
print "next2 is $next2; maxa2 = $maxa2; bin2 is $bin2\n";
