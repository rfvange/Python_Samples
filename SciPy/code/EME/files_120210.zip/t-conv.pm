$#ARGV>=0 || die "Specify number $!";
($num) = @ARGV;
$i = 0;
$ofile = q/t-file.txt/;
do {
  $n[$i++] = $num%256;
  $num = int($num/256);
} until $num == 0;
for($j=0;$j<$i;$j++) {
  print "$n[$j]\n";
}  
open (OFILE, ">$ofile");
for($j=0;$j<$i;$j++) {
  $a = pack("C",$n[$j]);
  print OFILE $a;
}
$a = pack("C",0);
for($k=$j;$k<4;$k++) {
  print OFILE $a;
}
close OFILE;
