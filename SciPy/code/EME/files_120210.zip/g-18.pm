#!/home/cardinal/home10/rfv0515j/perl/perl
$z = 256;
$p = 400;
%resarr = ();

while(<STDIN>) {
  $j = $_ if (/j =/);
  next unless (/i = 18/);
  last if eof();
  $_ = <STDIN>; chop;
  if(defined $resarr{$_}) {
    chop $resarr{$_}; $resarr{$_}.=", ".$j; }
  else {
    $resarr{$_}=$j; }
#  print;
}
@sres = reverse sort { $a <=> $b } keys %resarr;
foreach(@sres) { print $_,", ",$resarr{$_}; }

__END__

  @test = keys %resarr;
#  print "dim of test is $#test\n";
#  print "int intres = $intres, pound = $resarr{$intres}\n";
  last if eof();
}
print "Now sort\n";
@test = keys %resarr;
print "dim of test is $#test\n";
#foreach(keys %resarr) { print "testing: $_\n"; }
@sres = reverse sort { $a <=> $b } keys %resarr;
foreach(@sres) {
  print "$_,  ", $resarr{$_};
}
# unkn422-1.out is the raw data from the unk-.wav file.

$cmd4 = qq/fft2 unkn422-1.out -z=$z -p=$p > unkn422-2a.out/;
#$cmd1 = qq/lam-flt unkn422-2a.out -z=$z -p=$p -l=.7 > unkn422-3a.out/;
#   Edit band.pm for retained frequencies
$cmd5 = qq/band.pm $z $p < unkn422-2a.out > unkn422-3aa.out/; # w/o lamda-f
#$cmd5 = qq/band.pm $z $p < unkn422-3a.out > unkn422-3aa.out/; # w/ lamda-f
$cmd2 = qq/fft2 unkn422-3aa.out -z=$z -p=$p -i -v > unkn422-4a.out/;
$cmd3 = qq/to-wv.pm < unkn422-4a.out > unkn4-4a.wav/;
system($cmd4);   # forward fft
#system($cmd1);   # lambda filter
system($cmd5);   # retain desired frequencies
system($cmd2);   # inverse transform
system($cmd3);   # create .wav file
