#!/home/cardinal/home10/rfv0515j/perl/perl
$#ARGV>=0 || die "Specify a file: $!\n";
($file) = @ARGV;
#print "File is $file\n";
open(FILE,"<$file") || die "Can't read $file: $!";
seek(FILE,44,0);
#print "$b bytes read\n";
for($i=0;$i<10*8192;$i++) {
  read(FILE,$a,1);
  $c = unpack("C",$a);
  $c = 2*($c-128);
#  $d = pack("f",$c);
  print "$c\n";
  last if eof();
#  print $a;
}
close FILE;
