#!/home/cardinal/home10/rfv0515j/perl/perl
while(1) {
  $_ = <STDIN>;
  last if eof();
  $pound = $_ if /#/;
  next unless /#/;
  $a = <STDIN>; $b = <STDIN>;
#  print "$a, $b, $pound\n";
  if($a < 0) { $a = -$a; }
  if($b < 0) { $b = -$b; }
  if($a >= $b) { $res = $a*(1+0.5*$b/$a); }
  else         { $res = $b*(1+0.5*$a/$b); }
  if($res > $max) {
    $next2 = $next1; $bin2 = $bin1;
    $next1 = $next0; $bin1 = $bin0;
    $next0 = $max; $bin0 = $bin;
    $max = $res; $bin = $pound;}
#  print "max = $max, bin = $bin\n";
  last if eof();
}
print "max is $max; bin is $bin\n";
print "next0 is $next0; bin0 is $bin0\n";
print "next1 is $next1; bin1 is $bin1\n";
print "next2 is $next2; bin2 is $bin2\n";
