#!/home/cardinal/home10/rfv0515j/perl/perl
 
$#ARGV >= 1 || die "No files specified\n";

($infile,$outfile,$mult) = @ARGV;
#print "$infile,$outfile,$mult\n";
$mult = 1 unless $mult;
open(IN, "<$infile") || die "Error opening $infile\n";
open(OUT, "<$outfile") || die "Error opening $outfile\n";
while (<IN>) {
  $out = <OUT>; chop; chop $out;
#  print "$_, $out, $mult\n";
  $res = $_ + $mult * $out;
  print "$res\n";
}
