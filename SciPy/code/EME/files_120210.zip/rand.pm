#!/home/cardinal/home10/rfv0515j/perl/perl
for($loop=1;$loop<10;$loop++) {
  $sum = 0; $j=0; $k=0; $min=0; $max=0;
  srand($loop);
   for($i=0;$i<50000;$i++) {
    $a = rand(.9998) + .0001;
    $a = sqrt(-log($a));
    $a = rand()<0.5 ? -$a : $a;
    $sum += $a;
#   print "$a\n";
    if($a<0) {$j++;} else {$k++;}
    if($a > $max) {$max = $a;}
    if($a < $min) {$min = $a;}
  }
  printf("neg = %d,  pos = %d, loop = %d\n", $j,$k,$loop);
  printf("min = %10.8f,  max = %10.8f\n", $min,$max);
  printf("sum = %10.8f\n\n",$sum);
}
