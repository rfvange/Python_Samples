#!/home/cardinal/home10/rfv0515j/perl/perl
$#ARGV>=0 || die "Specify a file: $!\n";
($file) = @ARGV;
#print "File is $file\n";
open(FILE,"<$file") || die "Can't read $file: $!";
seek(FILE,44,0);
#print "$b bytes read\n";
#for($i=0;$i<100;$i++) {
do {
  read(FILE,$a,1);
  $c = unpack("C",$a);
  $c = 2*($c-128);
#  $d = pack("f",$c);
#  print "$d";
  print "$c\n";
} until eof(FILE);
close FILE;
