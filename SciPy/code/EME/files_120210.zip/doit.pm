#!/home/cardinal/home10/rfv0515j/perl/perl
$z = 256;
$p = 400;

# unkn422-1.out is the raw data from the unk-.wav file.

$cmd4 = qq/fft2 unkn422-1.out -z=$z -p=$p > unkn422-2a.out/;
#$cmd1 = qq/lam-flt unkn422-2a.out -z=$z -p=$p -l=.7 > unkn422-3a.out/;
#   Edit band.pm for retained frequencies
$cmd5 = qq/band.pm $z $p < unkn422-2a.out > unkn422-3aa.out/; # w/o lamda-f
#$cmd5 = qq/band.pm $z $p < unkn422-3a.out > unkn422-3aa.out/; # w/ lamda-f
$cmd2 = qq/fft2 unkn422-3aa.out -z=$z -p=$p -i -v > unkn422-4a.out/;
$cmd3 = qq/to-wv.pm < unkn422-4a.out > unkn4-4a.wav/;
system($cmd4);   # forward fft
#system($cmd1);   # lambda filter
system($cmd5);   # retain desired frequencies
system($cmd2);   # inverse transform
system($cmd3);   # create .wav file
