#!/home/cardinal/home10/rfv0515j/perl/perl
@ARGV >= 3 || die "Usage: rand-wv.pm <cycles> <points> <noise> <amplitude>\n";
($cy,$pt,$ns,$amp) = @ARGV;
$pi = 2.0*atan2(1.0,0.0);
$num = 0;
#print "$pi\n";
$file = q/qsig.dat/;
$file1 = q/qsig1.dat/;
$file2 = q/qsig2.dat/;
$wavfl = q/unkn422.wav/;
$owavfl = q/out.wav/;
srand(time() ^ ($$ + ($$ << 3)));
system("rm $file") if -e $file;
open(FILE, ">$file");
open(FILE1, ">$file1");
open(FILE2, ">$file2");
open(WFILE, "<$wavfl");
open(WOFILE, ">$owavfl");
read(WFILE,$buf,44);
print WOFILE $buf;
close WFILE;
for($i=0;$i<$pt;$i++) {
 $func = sin(2*$cy*$pi*$i/$pt);
 $a = rand(.9998) + .0001;
 $a = sqrt(-log($a));
 $a = rand()<0.5 ? -$a : $a;
#$a = $func;
 $a = $func + $ns * $a;
 print FILE "$a\n";
 $b = int($a*$amp+128);
 $c = pack("C",$b);
 print FILE1 "$b\n";
 print FILE2 $c;
 print WOFILE $c;
 ++$num;
}
close FILE;
close FILE1;
close FILE2;
seek(WOFILE,40,0);
&putsize();
close WOFILE;

sub putsize {
  $i = 0;
  $num = $pt;
  do {
    $n[$i++] = $num%256;
    $num = int($num/256);
  } until $num == 0;
  for($j=0;$j<$i;$j++) {
    print "$n[$j]\n";
  }  
  for($j=0;$j<$i;$j++) {
    $a = pack("C",$n[$j]);
    print WOFILE $a;
  }
  $a = pack("C",0);
  for($k=$j;$k<4;$k++) {
    print WOFILE $a;
  }
  1;
}
