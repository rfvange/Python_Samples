#!/home/cardinal/home10/rfv0515j/perl/perl
$mag = 0;
$num = 0;
$temp = qq/temp$$/;
$wavfl = q/unkn422.wav/;
$ascfl = q/ascfl.txt/;
#printf "File is $temp\n";
open(TEMP, "+>$temp") || die "Can't open file $temp $!";
while(<STDIN>) {
  next if (/^#/);
  print TEMP;
  $_ = -$_ unless ($_ > 0);
  $mag = $_ if($mag < $_);
  $_ = <STDIN>; # read im part
  $num++;
}
#print "num is $num\n";
open(WFILE,"<$wavfl") || die "Can't open file $wavfl $!";
read(WFILE,$buf,40);
print $buf; # write header to stdout;
close WFILE;
&putsize();
#print "Max mag = $mag\n";
$mag = 200/$mag;
#$mag = 80/$mag;
seek(TEMP,0,0);
open(ASCF, ">$ascfl");
while(<TEMP>) {
  chop;
  $a = pack("c",int($_ * $mag + 0.5));
#  $a = pack("C",(int($_ * $mag + 0.5) + 128));
  $as = unpack("c",$a);
  print ASCF "$as\n";
  print $a;
}
close TEMP;
close ASCF;
system("rm $temp");

sub putsize {
  $i = 0;
  do {
    $n[$i++] = $num%256;
    $num = int($num/256);
  } until $num == 0;
  for($j=0;$j<$i;$j++) {
    $a = pack("C",$n[$j]);
    print $a;
  }
  $a = pack("C",0);
  for($k=$j;$k<4;$k++) {
    print $a;
  }
  1;
}
