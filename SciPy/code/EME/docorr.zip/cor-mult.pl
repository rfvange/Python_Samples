#!/usr/local/bin/perl
# This script performs a point-by-point multiply the transformed files.
# The output is the correlation - multiplication by the complex conjugate
#  of FILE2.
# The input and output files are packed double binary values.

$#ARGV >= 2 || die "Usage: pp-mult.pm <size> <infile1> <infile2> - $!";

($n,$infile1,$infile2) = @ARGV;
#$debug = "pp-deb.bug"; # DEBUGF

open(IFILE1,"<$infile1") || die "Choke, gasp, $infile1 - $!";
open(IFILE2,"<$infile2") || die "Choke, gasp, $infile2 - $!";
#open(DEBUGF,">>$debug") || die "Choke, gasp, $debug - $!";
binmode(IFILE1);
binmode(IFILE2);
binmode(STDOUT);

#while(1) {
#  last if (eof(IFILE1) || eof(IFILE2));

for($i=0;$i<$n;++$i) {
  sysread(IFILE1,$_,8); # Read real value
#  syswrite(STDOUT,$_,8);
  $re1 = unpack("d",$_);
#  print DEBUGF "Real1 = $re1\n";
  sysread(IFILE1,$_,8); # Read imaginary value
#  syswrite(STDOUT,$_,8);
  $im1 = unpack("d",$_);
#  print DEBUGF "Imag1 = $im1\n";
  sysread(IFILE2,$_,8); # Read real value
#  syswrite(STDOUT,$_,8);
  $re2 = unpack("d",$_);
#  print DEBUGF "Real2 = $re2\n";
  sysread(IFILE2,$_,8); # Read imaginary value
#  syswrite(STDOUT,$_,8);
  $im2 = unpack("d",$_);
#  print DEBUGF "Imag2 = $im2\n";

# For correlation
  $reo = $re1*$re2 + $im1*$im2; # Multiply IFILE1 times the complex
  $imo = $re2*$im1 - $im2*$re1; #  conjugate of IFILE2.
# For convolution
#  $reo = $re1*$re2 - $im1*$im2; # Multiply IFILE1
#  $imo = $re2*$im1 + $im2*$re1; #   times IFILE2.
#  print DEBUGF "Realo = $reo\n";
#  print DEBUGF "Imago = $imo\n";

  $_ = pack("d",$reo); # Output the packed double result.
  syswrite(STDOUT,$_,8);
  $_ = pack("d",$imo);
  syswrite(STDOUT,$_,8);
}
close IFILE1;
close IFILE2;
#close DEBUGF;
