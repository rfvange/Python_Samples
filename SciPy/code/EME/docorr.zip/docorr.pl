#!/usr/local/bin/perl
# Note: $n must be less than the "chunk" length.
# That is $n < $p.
$msg1 = "Usage: docorr.pm <kernel_length> <fft-length>";
$msg2 = " <infile> <ascfile> > <output> - $!";
$#ARGV >= 3 || die "$msg1$msg2";

($n,$lfft,$infile,$asciif) = @ARGV;
$p = $lfft - $n + 1; # Length of chunk
$p>$n || die "Chunk length is too small. Increase fft size. - $!";

$ifftfile = "ifftfile.txt";
$file1 = "tfile1.dat";
$file2 = "kern.dat";
$file3 = "tfile.txt";
#$debug = "debug.bug"; # DEBUGF
$pp_out = "pp-out.dat";

$cmd1 = "fftfwd $ifftfile -z=$lfft -p=1 $file1 > $asciif";
$cmd2 = "perl cor-mult.pl $lfft $file1 $file2 > $pp_out";
$cmd3 = "fftinv $pp_out -z=$lfft -p=1 -i -v > $file3";

# Open the input file.
open(INFILE,"<$infile") || die "Choke, gasp, $infile - $!";
# Open the ASCII buffer file to input to the FFT.
open(IFFTFILE,"+>$ifftfile") || die "Choke, gasp, $ifftfile - $!";
# Open debug file
#open(DEBUGF,">$debug") || die "Choke, gasp, $debug - $!";

#print DEBUGF "infile is $infile\n";
#print DEBUGF "p = $p, n = $n, l = $lfft\n";

for($i=0;$i<$n-1;++$i) { # Fill the beginning of the chunk with N-1 0s.
  print IFFTFILE "0\n";
}

LOOP:
while(1) {
  for($i=0,$j=0;$i<$p-$n+1;++$i,++$j) {
    last LOOP unless $_ = <INFILE>; # Break out if input is exhausted.
    print IFFTFILE $_;
#    print DEBUGF "From infile: $_";
  }
  for($i=0;$i<$n-1;++$i,++$j) {
    last LOOP unless $_ = <INFILE>; # Break out if input is exhausted.
    print IFFTFILE $_;
    push(@buff,$_); # Save last N-1 values.
#    print DEBUGF "From infile and saving to buff: $_";
  }
  seek(IFFTFILE,0,0);
#  print DEBUGF "Printing $ifftfile\n";
#  while(<IFFTFILE>) { print DEBUGF "$_"; }
  close IFFTFILE;

  system("$cmd1"); # Forward FFT.

  system("$cmd2"); # Point-by-point multiply.

  system("$cmd3"); # Inverse FFT.

  open(OASCII,"<$file3") || die "Choke, gasp, $file3 - $!";
  for($i=0;$i<$p;++$i) { # Print the first P values to the output
    $_ = <OASCII>;
    redo if /^#/;
    print $_;
#    print DEBUGF "Saving from ifft: $_";
#    $_ = <OASCII>; # Discard imaginary.
  }
  for($i=0;$i<$n-1;++$i) { # Discard last N-1 values.
    $_ = <OASCII>;
    redo if /^#/;
#    print DEBUGF "Discarding: $_";
  }
  close OASCII;

# Open the ASCII buffer file to input to the FFT.
  open(IFFTFILE,"+>$ifftfile") || die "Choke, gasp, $ifftfile - $!";
  for($i=0;$i<$n-1;++$i) { # Put previous N-1 input values in the fft buffer.
    $_ = shift(@buff);
    print IFFTFILE $_;
#    print DEBUGF "Restoring from the buffer: $_";
  }

}

close INFILE;
$k = $p - $j; # Number of zeros appended to chunk.
for($i=0;$i<$k;++$i) { # Finish filling the chunk with zeros.
  print IFFTFILE "0\n";
#    print DEBUGF "Finishing filling the chunk with zeros\n";
}

#  seek(IFFTFILE,0,0); # Needed for DEBUGF
#  print DEBUGF "Printing $ifftfile\n";
#  while(<IFFTFILE>) { print DEBUGF "$_"; }
close IFFTFILE;

system("$cmd1");

system("$cmd2");

system("$cmd3");

open(OASCII,"<$file3") || die "Choke, gasp, $file3 - $!";
for($i=0;$i<$p-$k;++$i) { # Print the first P values
  $_ = <OASCII>; #              minus appended zeros to the output.
  redo if /^#/;
  print $_;
#    print DEBUGF "Outputting value: $_";
#  $_ = <OASCII>; # Discard imaginary part.
}

for($i=0;$i<$n-1;++$i) { # Discard last N-1 values.
  $_ = <OASCII>;
  redo if /^#/;
#    print DEBUGF "Discarding value: $_";
}
close OASCII;
#close DEBUGF;

#unlink $ifftfile;
#unlink $file1;
#unlink $file3;
#unlink $pp_out;
#unlink $asciif;
