$kernlen = 140;
$fftlen = 1024;
$freq = 930/8192;
$pi = atan2(0,-1);
#print "pi = $pi\n";
for($i=0;$i<$kernlen;++$i) {
  $out = cos(2*$pi*$freq*$i);
  print "$out\n";
}
for($i=$kernlen;$i<$fftlen;++$i) {
  print "0\n";
}
