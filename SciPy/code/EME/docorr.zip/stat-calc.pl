@ARGV==5 || die "Usage: <file-name> <skip> <lower-lim> <upper-lim> <end> - $!";
($file,$skip,$lower,$upper,$end) = @ARGV;

$end -= $upper;
++$upper>$lower || die "upper must be greater than lower - $!";
open(FILE, "<$file") || die "Error opening $file - $!";

for($i=0;$i<$skip;++$i) { $in = <FILE>; } # Skip
#print "in = $in\n";

for($i=0;$i<$upper;++$i) { # Fill pipe with $upper values
#  print "i = $i\n";
  chomp($in = <FILE>) || die "Ran out of data during initial fill - $!";
#  print "in = $in\n";
  push(@data,$in);
}

#foreach $a (@data) { print "a = $a\n"; }
#print "Here 1\n";

$j = 0;
while($skip++ < $end) {
#  print "skip = $skip\n";
  for($i=$lower;$i<$upper;$i++) {
#    print "i = $i, data[0] = $data[0], data[$i] = $data[$i]\n";
    $r[$i] += $data[0]*$data[$i];
  }
#print "Here 2\n";
#foreach $a (@data) { print "a = $a\n"; }
  unless (chomp($in = <FILE>)) {
    print "Prematurly ran out of data\n";
    last;
  }
  shift @data;
  push(@data,$in);
  ++$j;
}

#print "lower = $lower, upper = $upper, j = $j\n";
for($i=$lower;$i<$upper;++$i) {
  $r[$i] /= $j;
  print "r[$i] = $r[$i]\n";
}
