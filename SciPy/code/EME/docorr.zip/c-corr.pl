#!/home/cardinal/home10/rfv0515j/perl/perl

$pi = atan2(0.0,-1.0);
$fr = 0.2;
$base = "out";
$suff = ".txt";
$ns = 5.0;

srand(time() ^ ($$ + ($$ << 3)));
for($j=1;$j<5;++$j) {
  $out = 0;
  $outa = 0;
  $outb = 0;
  $outc = 0;
  $file = $base.$j.$suff;
#  print "name = $file\n";
  open(FILE,">$file") || die "Error opening $file - $!";
  for($i=0;$i<10000;++$i) {
    $a = rand(.9998) + .0001;
    $a = sqrt(-log($a));
    $a = rand()<0.5 ? -$a : $a;
    $out1 = cos(2*$pi*$fr*$i) + $ns*$a;
    $out1b = cos(2*$pi*$fr*$i);
    $out1a = $ns*$a;
#    print FILE "out1 = $out1\n";
    $a = rand(.9998) + .0001;
    $a = sqrt(-log($a));
    $a = rand()<0.5 ? -$a : $a;
    $out2 = cos(2*$pi*$fr*($i+5*$j)) + $ns*$a;
    $out2b = cos(2*$pi*$fr*($i+5*$j));
    $out2a = $ns*$a;
#    print FILE "out2 = $out2\n";
    $out += $out1*$out2;
    $outa += $out1a*$out2a;
    $outb += $out1b*$out2b;
    $outc += $out1*$out1b;
  }
  print FILE "$out\n";
  print FILE "$outb\n";
  print FILE "$outa\n";
  print FILE "$outc\n";
  close FILE;
}


__END__
@ARGV >= 4 || die "Usage: rand-mk.pl <cycles> <points> <noise> <amplitude>\n";
($cy,$pt,$ns,$amp) = @ARGV;
#print "$pi\n";
for($i=0;$i<$pt;$i++) {
 $func = $amp*sin(2*$cy*$pi*$i/$pt);
#$a = $func;
 $a = $func + $ns * $a;
 printf "%6.3f\n",$a;
}
