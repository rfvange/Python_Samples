#!/usr/local/bin/perl
#$#ARGV >= 1 || die "Usage: test1.pm <points> <frequency> - $!";
$pi = atan2(0,-1);
#print "$pi\n";
$c1 = 4096; $c2 = -4096/3;
$t1 = 64/2048;

for($j=0;$j<8;++$j) {
  for($i=0;$i<64;++$i) {
    $t = $i/2048;
    $freq = 544 + $c1*$t;
    $arg = (544 + $c1*$t)*$t;
    print "i = $i, t = $t, arg = $arg, freq = $freq\n";
    $u = 100*cos(2*$pi*(544 + $c1*$t)*$t);
    print int($u),"\n";
#    print "u = $u\n";
#    print "u = $u\n\n";
  }
  $fmax = 544 + $c1*$t1;
  for($i=0;$i<192;++$i) {
    $t = $i/2048;
    $freq = $fmax + $c2*$t;
    $arg = ($fmax + $c2*$t)*$t;
    print "i = ",$i+64,", t = $t, freq = $freq\n";
    $u = 100*cos(2*$pi*($fmax*$t + $c2*$t**2));
    print int($u),"\n";
#    print "u = $u\n";
#    print "u = $u\n\n";
  }
}

__END__
for($i=0;$i<64;++$i) {
  $t = $i/2048;
  $u = 100*cos(2*$pi*544*$t);
  printf "%10.4f\n",$u;
}
