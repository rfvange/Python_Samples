#!/usr/local/bin/perl
# Beta = pi*Alpha - In case you ever see that.

$#ARGV >= 2 || die "Usage: kaiser.pm <beta> <#pts> <infile> - $!";

($beta,$points,$infile) = @ARGV;
$am = ($points-1)/2;
$fio1 = fio($beta);
for($i=0;$i<2*$am+1;++$i) {
#  eval {$arg = $beta*sqrt(1-(($am-$i+1.5)/($am))**2);};
#  $arg = 0 if $@;
  $arg = $beta*sqrt(1-(($i-$am)/$am)**2);
  $w[$i] = fio($arg)/$fio1;
}

#$kout = "k-out.txt";
#open(KOUT,">$kout") || die "Choke, gasp, $kout - $!";
#for($i=0;$i<$points;++$i) {
#  printf KOUT "%8.4f\n",$w[$i];
#}
#close KOUT;

open(INFILE,"<$infile") || "Gasp, choke, $infile - $!";

for($i=0;$i<$points;++$i) {
  $_ = <INFILE>;
  chomp;
  $_ = $_ * $w[$i];
  $_ = int($_ - 0.5) if ($_<0);
  $_ = int($_ + 0.5) if ($_>=0);
  print "$_\n";
}
close INFILE;

sub fio {
  my($z) = @_;
  my($y,$e,$d,$i);
  $y = $z/2;
  $e = $d = 1;
  for($i=0;$i<25;++$i) {
    $d = $d*$y/($i+1);
    $d2 = $d**2;
    $e += $d2;
    goto EXIT if ($d2 < 1.0e-7);
  }
  print "Failed to converge\n";
  return;
  EXIT:
  $e;
}
