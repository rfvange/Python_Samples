#!/usr/local/bin/perl
# This script performs a point-by-point multiply the transformed files.
# The output is the correlation - multiplication by the complex conjugate
#  of FILE2.
# The input and output files are packed double binary values.

$#ARGV >= 2 || die "Usage: pp-mult.pm <size> <infile1> <infile2> - $!";

($n,$infile1,$infile2) = @ARGV;

open(IFILE1,"<$infile1") || die "Choke, gasp, $infile1 - $!";
open(IFILE2,"<$infile2") || die "Choke, gasp, $infile2 - $!";

#LOOP:
#while(1) {
#  last LOOP if (eof(IFILE1) || eof(IFILE2));
for($i=0;$i<$n;++$i) {
  sysread(IFILE1,$_,8); # Read real value
  $re1 = unpack("d",$_);
  sysread(IFILE1,$_,8); # Read imaginary value
  $im1 = unpack("d",$_);
  sysread(IFILE2,$_,8); # Read real value
  $re2 = unpack("d",$_);
  sysread(IFILE2,$_,8); # Read imaginary value
  $im2 = unpack("d",$_);
  print "Input: $re1, $im1, $re2, $im2\n";

  $reo = $re1*$re2 + $im1*$im2; # Multiply IFILE1 times the complex
  $imo = $re2*$im1 - $im2*$re1; #  conjugate if IFILE2.

  print "Output: $reo, $imo\n";
}
close IFILE1;
close IFILE2;

__END__
  $_ = pack("d",$re0); # Output the packed double result.
  syswrite(STDOUT,$_,8);
  $_ = pack("d",$im0);
  syswrite(STDOUT,$_,8);
}
