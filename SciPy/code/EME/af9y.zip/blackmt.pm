#!/usr/local/bin/perl
$#ARGV >= 0 || die "Usage: blackmt.pm <#pts> - $!";

$pi = atan2(0.0,-1.0);
($points) = @ARGV;
for($i=0;$i<$points;++$i) {
  $w[$i] = 0.42 - 0.5*cos(2*$pi*($i+1.5)/($points+2));
  $w[$i] += 0.08*cos(4*$pi*($i+1.5)/($points+2));
  printf "%10.4f\n",$w[$i];
}

__END__

open(INFILE,"<$infile") || "Gasp, choke, $infile - $!";

for($i=0;$i<$points;++$i) {
  $_ = <INFILE>;
  chomp;
  $_ = $_ * $w[$i];
  $_ = int($_ - 0.5) if ($_<0);
  $_ = int($_ + 0.5) if ($_>=0);
  print "$_\n";
}
close INFILE;
