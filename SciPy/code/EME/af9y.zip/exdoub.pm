#!/usr/local/bin/perl
$#ARGV>=0 || die "Usage: exdoub.pm <infile> - $!";
$infile = shift;
$tfile = "temp$$";
open(INFILE,"<$infile") || die "Choke, gasp, $infile - $!";
binmode(INFILE);
open(TEMP,"+>$tfile") || die "Choke, gasp, $tfile - $!";
$pi = atan2(0,-1);
$rtod = 180/$pi;

$max = 0;
$l10 = log(10);
$i = 0;
while(1) {
  sysread(INFILE,$a,8) || last; sysread(INFILE,$b,8) || last;
#  print ++$i,"\n";
  $re = $rea = unpack("d",$a); $im = $ima = unpack("d",$b);
  $re = -$re if ($re < 0);
  $im = -$im if ($im < 0);
# In the following, could do without squaring and still be within a dB.
#  $res = sqrt($re**2 + $im**2); # The exact calculation.

# A pretty good approximation.
#  $res = ($re>=$im) ? $re*(1+0.5*($im/$re)**2) : $im*(1+0.5*($re/$im)**2);

# A faster approximation.
  $res = ($re>=$im) ? ($re+0.5*$im) : ($im+0.5*$re);

  eval {$res1 = 20*log($res)/$l10;};
  $res1 = e-200 if $@;
  $angle = $rtod*atan2($ima,$rea);
  printf TEMP "%10.3f\n",$res1;
  printf "%10.3f, %10.3f, %10.3f, %10.3f, %10.3f\n",$res1,$res,$angle,$rea,$ima;
  $resmax = $res1 if ($res1 > $resmax);
}
close INFILE;

seek(TEMP,0,0);
print "\nRelative Output\n";
while(<TEMP>) {
  printf "%10.3f\n",$_-$resmax;
}

close TEMP;
unlink $tfile;
