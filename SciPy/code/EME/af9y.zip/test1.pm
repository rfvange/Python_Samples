#!/usr/local/bin/perl

while(1) {
  sysread(STDIN,$_,8) || last;
  $val = unpack("d",$_);
  print "$val,";
  sysread(STDIN,$_,8) || last;
  $val = unpack("d",$_);
  print "    $val\n";
}
