#!/usr/local/bin/perl
$#ARGV >= 2 || die "Usage: to-wvn.pm <infile> <wavefile> <outfile>\n";
$infile = shift; # Get input file size.
$wavfl = shift; # Get wave file from command line
$outfile = shift; # Output file
#$wavfl = q/\tyvc\sp-f3\unkn422.wav/;
#$infile = q/t-filt.out/;

open(INFILE,"<$infile") || die "Can\'t open file $infile $!";
open(OUTFILE,"+>$outfile") || die "Can\'t open file $outfile $!";
# Get the header
open(WFILE,"<$wavfl") || die "Can\'t open file $wavfl $!";
read(WFILE,$buf,40); # Up to size info
print OUTFILE $buf; # write header to stdout;
close WFILE;

$num = 0;
# Get filesize.
while(<INFILE>) { ++$num; }
$numa = $num + 36;

seek(INFILE,0,0); # Rewind the input file.

# Put in the file size
&putsize();

#$i = 0;
# Now write the info
while(<INFILE>) {
  chomp;
  $a = pack("C",(int($_ + 0.5) + 128));
#  $as = unpack("C",$a);
#  print ASCF $as-128,"\n";
  print OUTFILE $a;
#  last if $i++==500;
}

close INFILE;

seek(OUTFILE,4,0);
$num = $numa;
&putsize();
close OUTFILE;

sub putsize {
  $i = 0;
  do {
    $n[$i++] = $num%256;
    $num = int($num/256);
  } until $num == 0;
  for($j=0;$j<$i;$j++) {
    $a = pack("C",$n[$j]);
    print OUTFILE $a;
  }
  $a = pack("C",0);
  for($k=$j;$k<4;$k++) {
    print OUTFILE $a;
  }
  1;
}
