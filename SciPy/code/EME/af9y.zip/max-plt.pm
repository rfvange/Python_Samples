#!/usr/local/bin/perl
$#ARGV >= 1 || die "Usage: max-plt.pm <max-value> <infile> > outfile.out - $!";
# $max = 8000000;
$max = shift;
while(<>) {
  if($_ < 0) {
    if($_ > -$max/8)   { print "                  1\n"; next; }
    if($_ > -2*$max/8) { print "                2\n"; next; }
    if($_ > -3*$max/8) { print "              3\n"; next; }
    if($_ > -4*$max/8) { print "            4\n"; next; }
    if($_ > -5*$max/8) { print "          5\n"; next; }
    if($_ > -6*$max/8) { print "        6\n"; next; }
    if($_ > -7*$max/8) { print "      7\n"; next; }
                         print "    8\n";
  }
  else {
    if($_ < $max/8)   { print "                   1\n"; next; }
    if($_ < 2*$max/8) { print "                     2\n"; next; }
    if($_ < 3*$max/8) { print "                       3\n"; next; }
    if($_ < 4*$max/8) { print "                         4\n"; next; }
    if($_ < 5*$max/8) { print "                           5\n"; next; }
    if($_ < 6*$max/8) { print "                             6\n"; next; }
    if($_ < 7*$max/8) { print "                               7\n"; next; }
                        print "                                 8\n";
  }
}
