#!/usr/local/bin/perl
$msg = "Usage: max-pltc.pm <sample> <max-value> <infile> > outfile.out - $!";
$#ARGV >= 2 || die "$msg";
$sample = shift;
$max = shift;

$cnt = 0;
$maxi = 0;
while(<>) {
  $_ = -$_ if ($_ < 0);
  $maxi = $_ if ($_ > $maxi);

  if(++$cnt == $sample) {
    if($maxi < $max/8)   { print "   1\n"; $cnt = $maxi = 0; next; }
    if($maxi < 2*$max/8) { print "     2\n"; $cnt = $maxi = 0; next; }
    if($maxi < 3*$max/8) { print "       3\n"; $cnt = $maxi = 0; next; }
    if($maxi < 4*$max/8) { print "         4\n"; $cnt = $maxi = 0; next; }
    if($maxi < 5*$max/8) { print "           5\n"; $cnt = $maxi = 0; next; }
    if($maxi < 6*$max/8) { print "             6\n"; $cnt = $maxi = 0; next; }
    if($maxi < 7*$max/8) { print "               7\n"; $cnt = $maxi = 0; next; }
                           print "                 8\n"; $cnt = $maxi = 0;
  }
}
