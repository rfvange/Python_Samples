#!/usr/local/bin/perl
$#ARGV >= 1 || die "Usage: test1.pm <points> <frequency> - $!";
$pi = atan2(0,-1);
print "$pi\n";
#$points = 32;
$points = shift;
#$freq = 2;
$freq = shift;
for($i=0;$i<$points;++$i) {
  $u = ($i**2)%($points-1)/$points;
  print "$u\n";
  $u = (($freq*($i**2))%($points-1))/$points;
  print "$u\n";
  $u = 100*cos(2*$pi*(($freq*($i**2))%($points-1))/$points);
#  $u = 100*cos(2*$pi*$freq*$i**2/(2*$points-1));
#  $u = 100*cos(2*$pi*$freq*$i**2/$points**2);
#  print $u,"\n";
  print int($u),"\n";
  print "\n";
}
