#!/usr/local/bin/perl
$#ARGV >= 2 || die "Usage: peak.pm <hfile> <ffile> <outfile> - $!";
($hfile,$ffile,$outfile) = @ARGV;
open(HFILE,"<$hfile") || die "Choke, gasp, $hfile - $!";
open(FFILE,"<$ffile") || die "Choke, gasp, $ffile - $!";
open(OFILE,">$outfile") || die "Choke, gasp, $outfile - $!";

while(<HFILE>) { # Fill up the transfer function
  push(@h,$_); # For correlation.
#  unshift(@h,$_); # For convolution.
}
print "Length of transfer function = ",$#h+1,"\n";

close HFILE;

for($i=0;$i<$#h;++$i) { # Fill all but the last one
  $_ = <FFILE>;
  push(@f,$_);
}

while(<FFILE>) {
  push(@f,$_); # Push newest value onto array
#  print "length of f = ",$#f+1,", length of h = ",$#h+1,"\n";
  $g = 0;
  for($i=0;$i<=$#h;++$i) { # Correlate
    $g += $f[$i]*$h[$i];
  }
  printf OFILE "$g\n";
  shift(@f); # Discard oldest value
}
close FFILE;
close OFILE;
