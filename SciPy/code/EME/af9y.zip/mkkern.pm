#!/usr/local/bin/perl
# This script makes the augmented kernel of the filter.
$#ARGV>=1 || die "Usage: mkkern.pm <fft-length> <kern-s> > kern-l - $!";
$lfft = shift;

$i = 0;
while(<>){
  ++$i;
  print;
}

while(1){
  last if ++$i>$lfft;
  print "0\n";
}
