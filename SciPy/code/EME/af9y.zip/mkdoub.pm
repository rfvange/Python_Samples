#!/usr/local/bin/perl

while(<>) {
  $val = pack("d",$_);
  print $val;
}
