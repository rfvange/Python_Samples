#!/usr/local/bin/perl
$#ARGV >= 0 || die "Usage: c-peak.pm <file> - $!";
$max = 0;
while(<>) {
  chomp;
#  print "Befort subst: $_\n";
   $_ += 0;
#  s/^ *(-*.+)$/$1/;
#  print "After subst: $_\n";
#  $_ = -$_;
#  $_ = -$_ if ($_>=0);
#  $_>0;
  $_ = -$_ if ($_<0);
  if($_>$max) {
    print "Pushing $_, max = $max\n";
    push(@max,$_);
    $max = $_;
  }
}
print "#max = $#max\n";
$x = $#max+1;
$score = 0;
for($i=0;$i<$x;++$i) {
  $_ = pop(@max);
  print "$i, $_\n";
  $score += $_;
}
print "Score = $score\n";
